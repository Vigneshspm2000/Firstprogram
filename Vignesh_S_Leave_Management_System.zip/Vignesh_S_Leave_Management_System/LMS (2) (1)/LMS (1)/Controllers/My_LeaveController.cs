using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using LMS.Models;

using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;
namespace LMS.Controllers;



public class My_Leave : Controller
{
    private readonly ILogger<My_Leave> _logger;
  
    public string s1="Apply";
    public string s2="Accept";

    public object Session { get; private set; }

    public My_Leave(ILogger<My_Leave> logger)
    {
        _logger = logger;
    }
    [HttpGet]
    public IActionResult Signup()
    {
        return View();
    }
    [HttpPost]
     public IActionResult Signup(Signup Value)
    {
        string result = Repository.EnterTable(Value);

        if(result == "Ok")
        {
        HttpContext.Session.SetString("Session",Value.UserID);
         var cookieOptions = new CookieOptions();
         cookieOptions.Expires = DateTime.Now.AddDays(1);
         Response.Cookies.Append("LastLoginTime",DateTime.Now.ToString(),cookieOptions);
         Console.WriteLine(Request.Cookies["LastLoginTime"]);
         TempData["Time"]="Last Login:"+Request.Cookies["LastLoginTime"];
        
        return RedirectToAction("Login","Home");
        }
        else{
            ViewBag.Message="Wrong Username Or passWord ";
            return View();
        }
    }
    [HttpGet]
        public IActionResult ReEnterPassWord()
        {
            return View();
        }
        [HttpPost]
        public IActionResult ReEnterPassWord(ForgetPassWord ResetPassWord)
        {
            if(!string.IsNullOrEmpty(HttpContext.Session.GetString("Session"))){
            string result = Repository.ForgetPassWord(ResetPassWord);
            if(result=="ok")
            {
            return View("ReEnterPassWord");
            }
            else
            {
                ViewBag.Message1="Wrong UserName";
                return View("ReEnterPassWord");
            }
            }
            return View("Signup");
         }
         [HttpGet]
         public IActionResult RequestLeave()
         {
             Regex regex = new Regex("^(?=.*?[INT])(?=.*?[00])(?=.*?[0-9]).{8,8}$");
            if(regex.IsMatch(HttpContext.Session.GetString("Session"))==true)
            { 
            return View();
            }
         return View("Signup");
         }
        
        [HttpPost]
        public IActionResult RequestLeave(RequestLeaveDetails leb,string Submit)
        {
            
            
            
            
            string result= Repository.LeaveRequest(leb); 
            
           
           
            if(result=="ok")
            { 
            SqlConnection sqlconn = new SqlConnection("Data source= DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI");
            sqlconn.Open();
            SqlCommand command = new SqlCommand("update Table_3 set EmRequest='"+Submit+"';",sqlconn);
            command.ExecuteNonQuery();
            sqlconn.Close();
            return View();
            }
            else
            {
                ViewBag.Message="Wrong Data";
                return View();
             }
            
        
        }
       
        
        
        public IActionResult ShowLeaveDetails(string? empsearch)
        {
            Regex regex2 = new Regex("^(?=.*?[AD])(?=.*?[00])(?=.*?[0-9]).{7,7}$");
            
            if(regex2.IsMatch(HttpContext.Session.GetString("Session"))==true)
            {
                
            
            SqlConnection sqlconn = new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI");   
            string?  sqlquery = "select*from Table_3 where Userid like '%"+empsearch+"%' or Mail like '%" + empsearch+"%' or UserName like '%"+empsearch+"%' or Start_Date like '%"+empsearch+"%' or End_Date like '%"+empsearch+"%' or EmRequest like '%"+empsearch+"%' or ManRequest like '%"+empsearch+"%' ";
            SqlCommand sqlcomm = new SqlCommand(sqlquery,sqlconn);
             sqlconn.Open();
            SqlDataAdapter sda = new SqlDataAdapter(sqlcomm);
            System.Data.DataSet ds = new System.Data.DataSet();
             sda .Fill(ds);
             List<RequestLeaveDetails> ec =new List<RequestLeaveDetails>();
             foreach(System.Data.DataRow dr in ds.Tables[0].Rows)
             {
                ec.Add(new RequestLeaveDetails {
                    UserName =Convert.ToString(dr["UserName"]),
                    Email = Convert.ToString(dr["Mail"]),
                    UserID = Convert.ToString(dr["Userid"]),
                    StartDate=Convert.ToString(dr["Start_Date"]),
                    EndDate=Convert.ToString(dr["End_Date"]),
                    LeaveType=Convert.ToString(dr["Leave_Type"]),
                    Description=Convert.ToString(dr["Des"]),
                    EmRequest=Convert.ToString(dr["EmRequest"]),
                    ManRequest = Convert.ToString(dr["ManRequest"])
                });
             }
            
             ModelState.Clear();
             return View(ec);
          
            }

            return View("Signup");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.SetString("Session","");
            return RedirectToAction("Index","Home");
        }
      
        [HttpGet]
        public IActionResult CancelLeave()
        {
             Regex regex = new Regex("^(?=.*?[INT])(?=.*?[00])(?=.*?[0-9]).{8,8}$"); 
            if(regex.IsMatch(HttpContext.Session.GetString("Session"))==true)                                                                      
            {
            return View();
            }
            return View("Signup");
        }
        [HttpPost]
         public IActionResult CancelLeave(CancelRequest RLD)
        {
          
                
            string result=Repository.RemoveDetails(RLD);
           // Console.WriteLine(result);
            if(result == "ok")
            {
            return View("RequestLeave");
            }
            return View();
         
        }
       
       
       

     [HttpGet]

       public IActionResult LeaveSummary(RequestLeaveDetails LER)
        {
            
           
            string Name = HttpContext.Session.GetString("Session").ToString();
            Console.WriteLine(Name);
             
            
            SqlConnection sqlconn = new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI");   
            sqlconn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from Table_6 where UserName ='"+Name+"';",sqlconn);
            System.Data.DataSet ds = new System.Data.DataSet();
             sda .Fill(ds);
             List<RequestLeaveDetails> ec =new List<RequestLeaveDetails>();
             foreach(System.Data.DataRow dr in ds.Tables[0].Rows)
             {
                ec.Add(new RequestLeaveDetails {
            Privileged_Leave=((int)dr["Privileged_Leave"]),
            Compansatory_Leave=((int)dr["Compansatory_Leave"]),
            Maternity_Leave=((int)dr["Maternity_Leave"]),
            Paternity_Leave=((int)dr["Paternity_Leave"]),
            LOP_Leave=((int)dr["LOP_Leave"]),
            Carry_Forward=((int)dr["Carry_Leave"]),
            Encashed_Days=((int)dr["Encashed_Leave"]),
            Marriage_Leave=((int)dr["Marriage_Leave"]),
            MTP_Leave=((int)dr["MTP_Leave"]),
            UserName = (dr["UserName"].ToString()),
            UserID = (dr["UserID"].ToString())
            
            
            
                });
             }
            
             ModelState.Clear();
             return View(ec);
         
            
        } 

        [HttpPost] // [HttpGet]
        public IActionResult Compansatory_Eligibility( RequestLeaveDetails LER ,string username, string userid, string sDate, string EDate,string Submit,string Type)
        {
        
       
           if(!string.IsNullOrEmpty(HttpContext.Session.GetString("Session")))
           {
            // Console.WriteLine(Type);
            int privileged=0, Compansatory=0,Maternity=0,Paternity=0,MTP=0,Marriage=0,Carry=0,LOP=0,Encashed=0;
           
           SqlConnection sqlconn = new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI");
            
            
           sqlconn.Open();
           SqlCommand command = new SqlCommand("select count(*) from Table_3 WHERE Userid='"+userid+"'AND UserName ='"+username+"'AND Start_Date='"+sDate+"'AND End_Date='"+EDate+"';",sqlconn);
           int count = Convert.ToInt32(command.ExecuteScalar());
        //    Console.WriteLine(count);
           sqlconn.Close();
        
      
    
           if(count>0)
           {
           
            sqlconn.Open();
            SqlCommand command1= new SqlCommand("Update Table_3 set ManRequest='"+Submit+"' where Userid='"+userid+"'AND UserName ='"+username+"'AND Start_Date='"+sDate+"'AND End_Date='"+EDate+"';",sqlconn);
            command1.ExecuteNonQuery();
            sqlconn.Close();
            int Value =0;
           
            SqlCommand sqlcommand = new SqlCommand("select * from Table_3 where Userid='"+userid+"'AND UserName ='"+username+"'AND Start_Date='"+sDate+"'AND End_Date='"+EDate+"' AND ManRequest='"+s2+"' AND EmRequest='"+s1+"' AND Leave_Type ='"+Type+"';",sqlconn );
            
            
        
            sqlconn.Open();
             SqlDataReader srd = sqlcommand.ExecuteReader();
           
             while(srd.Read())
             {
                if((srd["Userid"].Equals(userid))&&(srd["UserName"].Equals(username))&&(srd["Start_Date"].Equals(sDate))&&(srd["End_Date"].Equals(EDate))&&(srd["ManRequest"].Equals(s2))&&(srd["EmRequest"].Equals(s1))&&(srd["Leave_Type"].Equals(Type))==true)
                {
                    Value = Value+1;
                }
               
             }
             sqlconn.Close();
             Console.WriteLine(Value);
            
           

            if(Value == 1)
            {
            SqlCommand command5 =new SqlCommand("select* from Table_6 where UserName ='"+username+"' and UserID ='"+userid+"';",sqlconn);
            
            
            Console.WriteLine(username);
            sqlconn.Open();
            SqlDataReader sdr = command5.ExecuteReader(); 
           
             
            while(sdr.Read())
            {
           
                
               
                if(Type.Equals("Privileged Leave")==true)
                {
                    
                    privileged = ((int)sdr["Privileged_Leave"]-1);
                   
                    
            
                 
                }
                else if(Type.Equals("Compensatory Leave")==true)
                {
                
                     
                  Compansatory = ((int)sdr["Compansatory_Leave"]-1);
                }
                else if(Type.Equals("Maternity Leave")==true)
                {
                   
                  Maternity = ((int)sdr["Maternity_Leave"]-1);
                }
                else if(Type.Equals("Paternity Leave")==true)
                {
                  Paternity = ((int)sdr["Paternity_Leave"]-1);
                }  
                else if(Type.Equals("LOP Leave")==true)
                {
                    LOP = ((int)sdr["LOP_Leave"]-1);
                }
                else if(Type.Equals("Carry Forward")==true)
                {
                    Carry = ((int)sdr["Carry_Leave"]-1);
                }
                else if(Type.Equals("Encashed Days")==true)
                {
                    Encashed= ((int)sdr["Encashed_Leave"]-1);
                }
                else if(Type.Equals("Marriage Leave")==true)
                {
                    Marriage = ((int)sdr["Marriage_Leave"]-1);
                }
                else if(Type.Equals("MTP Leave")==true)
                {
                    MTP = ((int)sdr["MTP_Leave"]-1);
                }
                
            }
            // Console.WriteLine(privileged);
            sqlconn.Close();
            if(Type.Equals("Privileged Leave")==true)
            {
                sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set  Privileged_Leave='"+ privileged +"' where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
            }
            else if(Type.Equals("Compensatory Leave")==true)
                {
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set  Compansatory_Leave='"+ Compansatory+"' where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
                }
            else if(Type.Equals("Maternity Leave")==true)
            {
                    
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set Maternity_Leave ='"+Maternity+"'where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
            }

            else if(Type.Equals("Paternity Leave")==true)
                {
                    
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set Paternity_Leave='"+Paternity+"' where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
                }
                else if(Type.Equals("LOP Leave")==true)
                {
                    
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set LOP_Leave='"+LOP+"' where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
                }
                else if(Type.Equals("Carry Forward")==true)
                {
                    
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set Carry_Leave='"+Carry+"' where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
                }
               else  if(Type.Equals("Encashed Days")==true)
                {

                    
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set Encashed_Leave='"+Encashed+"'where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
                   
                }
               else if(Type.Equals("Marriage Leave")==true)
                {
                    
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set Marriage_Leave='"+Marriage+"' where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
                }
               else if(Type.Equals("MTP Leave")==true)
                {
                    
                 sqlconn.Open();
                 SqlCommand command2= new SqlCommand("Update Table_6 set MTP_Leave='"+MTP+"' where Userid='"+userid+"'AND UserName ='"+username+"';",sqlconn);
                 command2.ExecuteNonQuery();
                 sqlconn.Close();
                }
           sqlconn.Open();
           SqlDataAdapter dataAdapter = new SqlDataAdapter( "select*from Table_6 where UserName ='"+username+"' and UserID ='"+userid+"';", sqlconn);
           System.Data.DataSet ds = new System.Data.DataSet();
           dataAdapter .Fill(ds);
           List<RequestLeaveDetails> ec =new List<RequestLeaveDetails>();
           
                   
            foreach(System.Data.DataRow dr in ds.Tables[0].Rows)
            {
            ec.Add(new RequestLeaveDetails 
            {
            
            Privileged_Leave=((int)dr["Privileged_Leave"]),
            Compansatory_Leave=((int)dr["Compansatory_Leave"]),
            Maternity_Leave=((int)dr["Maternity_Leave"]),
            Paternity_Leave=((int)dr["Paternity_Leave"]),
            LOP_Leave=((int)dr["LOP_Leave"]),
            Carry_Forward=((int)dr["Carry_Leave"]),
            Encashed_Days=((int)dr["Encashed_Leave"]),
            Marriage_Leave=((int)dr["Marriage_Leave"]),
            MTP_Leave=((int)dr["MTP_Leave"]),
            UserName = (dr["UserName"].ToString()),
            UserID = (dr["UserID"].ToString()),
            DateTime = (dr["DateTime"].ToString())
            
            
            });
            }
             ModelState.Clear();
             return View(ec);  
           }}
           sqlconn.Open();
           SqlDataAdapter data = new SqlDataAdapter( "select*from Table_6 where UserName ='"+username+"' and UserID ='"+userid+"';", sqlconn);
           System.Data.DataSet da = new System.Data.DataSet();
           data .Fill(da);
           List<RequestLeaveDetails> ecb =new List<RequestLeaveDetails>();
           foreach(System.Data.DataRow dr in da.Tables[0].Rows)
            {
            ecb.Add(new RequestLeaveDetails 
            {
            
            Privileged_Leave=((int)dr["Privileged_Leave"]),
            Compansatory_Leave=((int)dr["Compansatory_Leave"]),
            Maternity_Leave=((int)dr["Maternity_Leave"]),
            Paternity_Leave=((int)dr["Paternity_Leave"]),
            LOP_Leave=((int)dr["LOP_Leave"]),
            Carry_Forward=((int)dr["Carry_Leave"]),
            Encashed_Days=((int)dr["Encashed_Leave"]),
            Marriage_Leave=((int)dr["Marriage_Leave"]),
            MTP_Leave=((int)dr["MTP_Leave"]),
            UserName = (dr["UserName"].ToString()),
            UserID = (dr["UserID"].ToString()),
             DateTime = (dr["DateTime"].ToString())
            
            
            });
            }
             ModelState.Clear();

             return View(ecb);
        }
         return View("Signup");
        }
        [HttpGet]
        public IActionResult ManagerCheckingLeave()
       {
             return View();
       }
       [HttpPost]
       public IActionResult ManagerCheckingLeave(RequestLeaveDetails RLD)
       {

            TempData["mydata"]=RLD.UserID;
            // Console.WriteLine( TempData["mydata"]);
            
            return RedirectToAction("EmplyoeeLeaveDetail","My_Leave");
        }
        [HttpGet]
        public IActionResult EmpChecking()
        {
            return View();
        }
        [HttpPost]
        public IActionResult EmpChecking(RequestLeaveDetails EC)
        {
            TempData["EmpData"] = EC.UserID;
            return RedirectToAction("Show_Result","My_Leave");
        }
        [HttpGet]
        public IActionResult EmplyoeeLeaveDetail()
       {
        // Console.WriteLine("Hello"); 
        string? EmpID = TempData["mydata"].ToString();
        // Console.WriteLine(EmpID);
        SqlConnection sqlconn = new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI");
          
           sqlconn.Open();
           SqlDataAdapter data = new SqlDataAdapter( "select * from Table_6 where UserID='"+EmpID+"';", sqlconn);
           System.Data.DataSet da = new System.Data.DataSet();
           data .Fill(da);
           List<RequestLeaveDetails> ecb =new List<RequestLeaveDetails>();
           foreach(System.Data.DataRow dr in da.Tables[0].Rows)
            {
            ecb.Add(new RequestLeaveDetails 
            {
            
            Privileged_Leave=((int)dr["Privileged_Leave"]),
            Compansatory_Leave=((int)dr["Compansatory_Leave"]),
            Maternity_Leave=((int)dr["Maternity_Leave"]),
            Paternity_Leave=((int)dr["Paternity_Leave"]),
            LOP_Leave=((int)dr["LOP_Leave"]),
            Carry_Forward=((int)dr["Carry_Leave"]),
            Encashed_Days=((int)dr["Encashed_Leave"]),
            Marriage_Leave=((int)dr["Marriage_Leave"]),
            MTP_Leave=((int)dr["MTP_Leave"]),
            UserName = (dr["UserName"].ToString()),
            UserID = (dr["UserID"].ToString()),
            DateTime=(dr["DateTime"].ToString())
            
            
            });
            }
            
             ModelState.Clear();
             return View(ecb);
       }
       

        [HttpPost]
        public IActionResult EmplyoeeLeaveDetail(RequestLeaveDetails RLD)
        {
         
        //   string? EmpID = TempData["mydata"].ToString();
          Console.WriteLine("Hello"); 
        

          return View();
            // return View(Repository.AllList);
        }
         [HttpGet]
        
        public IActionResult Show_Result()
        {
           string? EmpID =  TempData["EmpData"].ToString();
           SqlConnection sqlconn = new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI");
           sqlconn.Open();
           SqlCommand command = new SqlCommand("select count(*) from Table_3 WHERE Userid='"+EmpID+"';",sqlconn);
           Console.WriteLine("Hello");
           int count = Convert.ToInt32(command.ExecuteScalar());
           sqlconn.Close();
           if(count>0)
           {
           sqlconn.Open();
           SqlDataAdapter data = new SqlDataAdapter( "select*from Table_3 where Userid='"+EmpID+"';", sqlconn);
           System.Data.DataSet da = new System.Data.DataSet();
           data .Fill(da);
           List<RequestLeaveDetails> ecb =new List<RequestLeaveDetails>();
           foreach(System.Data.DataRow dr in da.Tables[0].Rows)
            {
            ecb.Add(new RequestLeaveDetails 
            {
            
                    UserName =Convert.ToString(dr["UserName"]),
                    Email = Convert.ToString(dr["Mail"]),
                    UserID = Convert.ToString(dr["Userid"]),
                    StartDate=Convert.ToString(dr["Start_Date"]),
                    EndDate=Convert.ToString(dr["End_Date"]),
                    LeaveType=Convert.ToString(dr["Leave_Type"]),
                    Description=Convert.ToString(dr["Des"]),
                    EmRequest=Convert.ToString(dr["EmRequest"]),
                    ManRequest = Convert.ToString(dr["ManRequest"])
            
            
            });
            }
             ModelState.Clear();
             return View(ecb);

           }
           else{
             ViewBag.Message="Wrong Data";
             return View();

           }

        }
      [HttpGet]
     public IActionResult Send_Message()
      {
        // HttpClient hc = new HttpClient();
        // string Link = new Uri("");
        // HttpClient httpclient=new HttpClient();
        // string apiurl="http://localhost:5177/api/WeatherForecast";
        // var apiresponse=httpclient.GetAsync(apiurl).Result;
        // var send_Mail=apiresponse.Content.ReadAsAsync<IEnumerable<EmailClass>>().Result;
        // return View( send_Mail);
        // HttpClient httpClient = new HttpClient();
        // string apiUrl = ("http://localhost:5234/api/WeatherForecast");

        // var responseofapi = httpClient.GetAsync(apiUrl).Result;

        // var Sendmail = responseofapi.Content.ReadAsAsync<EmailClass>().Result;
        return View();
       
     
      }

        
                 
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
} 