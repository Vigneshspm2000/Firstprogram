using System;
namespace LMS.Models{
    public class CancelRequest
    {
        public string?ID{get;set;}
        public string? Name{get;set;}
        public string? SDate{get;set;}
        public string? EDate{get;set;}
        public string? LT{get;set;}
    }


}