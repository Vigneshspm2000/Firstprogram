using System;
using System.ComponentModel.DataAnnotations;

namespace LMS.Models
{
    public class Register
    {
        [Key]
        public string ? Userid{get;set;}
        [Required]
         public string ? Username{get;set;}
          public string ? Email{get;set;}
           public string ? Phone{get;set;}
            public string ? Address{get;set;}


    }
}