using System;
namespace LMS.Models{
    public class ForgetPassWord{
    public string? Name{get;set;}
    public string? PassWord2{get;set;}
    }

}