using System;
namespace LMS.Models
{
    public class RequestLeaveDetails
    {
        public string? UserID{get;set;}
        public string? UserName{get;set;}
        public string? StartDate{get;set;}
        public string? EndDate{get;set;}
        public string? LeaveType{get;set;}
        public string? Email{get;set;}
        public string? EmRequest{get;set;}
        public string? ManRequest{get;set;}
        public string? Description{get;set;}
        public string? Type{get;set;}
        public int Privileged_Leave{get;set;}
        public int Compansatory_Leave{get;set;}
        public int Maternity_Leave{get;set;}
        public int Paternity_Leave{get;set;}
        public int LOP_Leave{get;set;}
        public int Carry_Forward{get;set;}
        public int Encashed_Days{get;set;}
        public int Marriage_Leave{get;set;}
        public int MTP_Leave{get;set;}

        public string? DateTime{get;set;}        
         


    }
}