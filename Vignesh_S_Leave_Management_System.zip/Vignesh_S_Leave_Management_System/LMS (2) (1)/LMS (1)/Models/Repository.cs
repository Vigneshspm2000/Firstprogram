using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;
using LMS.Controllers;
using System;


#nullable disable

namespace LMS.Models
{
    public class Repository{
   
     public static List <RequestLeaveDetails> names = new List<RequestLeaveDetails> ();
        static SqlConnection connection =  new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI");
        public static IEnumerable<RequestLeaveDetails> AllList
        {
         get{
                return names;
            }
        }
       
        public static string EnterTable(Signup User)
        {
           
            string UsName=User.UserName;
            string  Uspass= User.PassWord;
            Regex regex = new Regex("^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9]).{10,}$");
            Regex regex2 = new Regex("^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[!@#$%^&*-]).{8,}$");

            
           //SqlConnection sqlconnection =  new SqlConnection("Data source = ASPIRE2017;Initial Catalog = Vignesh;integrated security=SSPI");
            connection.Open();
            SqlCommand sqlCommand = new SqlCommand("select count(*) from Table_2 WHERE UserName='"+UsName+"' AND PassWord='"+ Uspass+" ';",connection);
            int count=Convert.ToInt32(sqlCommand.ExecuteScalar());
          //  Console.WriteLine(count);
             connection.Close();
            
            if(regex.IsMatch(UsName)==true){
            if(regex2.IsMatch(Uspass)==true){
                if(count >0)
                {
                    return "Ok";
                }
                else{
                   return "Notok";
                }
                }
                else{
                    return "Notmatch";
                }
            }
            else{
                return "Notmatch";
            
            }
        }
    public static string ForgetPassWord(ForgetPassWord passWord)
    {

        string Name= passWord.Name;
            
        string Pass= passWord.PassWord2;
            using(SqlConnection connection =  new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI"))
            {
            connection.Open();
            SqlCommand commandRead = new SqlCommand("select count(*) from Table_2 WHERE UserName = '"+Name+"' ;",connection);
            int count=Convert.ToInt32(commandRead.ExecuteScalar());
          
            Regex regex2 = new Regex("^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[!@#$%^&*-]).{8,}$");
           
          //  Console.WriteLine(count);
            
            if(regex2.IsMatch(Pass)==true)
            {
                // try{
                if(count>0)
                  {
                using(SqlConnection connection2=  new SqlConnection("Data source = DESKTOP-1MRHJV7;Initial Catalog = Vignesh;integrated security=SSPI"))
            {
                  connection2.Open();
                  SqlCommand Update = new SqlCommand("Update Table_2 set PassWord='"+Pass+"' where UserName='"+Name+"' ;",connection2);
                  Update.ExecuteNonQuery();
                  
            } 
                  return "ok";
                 }else
                 {
            
                 return "NotOk";
                 }
                // }
                // finally{
                //     

                // }
            }
            
            
         
         return "NotOk";
            }
     
        }
        public static string  LeaveRequest(RequestLeaveDetails RLD)

        {
            
            Regex regex = new Regex("^(?=.*?[INT])(?=.*?[00])(?=.*?[0-9]).{8,8}$");
            Regex regex2 = new Regex("^(?=.*?[AD])(?=.*?[00])(?=.*?[0-9]).{7,7}$");
            int count= 2;
            if(count>0)
            {
             
                connection.Open();
               SqlCommand command1 = new SqlCommand("insert into Table_3(Userid,UserName,Mail,Des,Start_Date,End_Date,Leave_Type) values ('"+RLD.UserID+"','"+RLD.UserName+"','"+RLD.Email+"','"+RLD.Description+"','"+RLD.StartDate+"','"+RLD.EndDate+"','"+RLD.LeaveType+"');",connection);
               command1.ExecuteNonQuery();
               connection.Close();
               
               connection.Open();
               SqlDataAdapter sqlDataAdapter= new SqlDataAdapter();
               DataTable dataTable = new DataTable();
               connection.Close();
               connection.Open();
               SqlDataAdapter dataAdapter = new SqlDataAdapter( "select*from Table_6", connection);
               dataAdapter.Fill(dataTable);
               
           foreach(DataRow dr in dataTable.Rows)
            {
            RequestLeaveDetails user = new RequestLeaveDetails();
            
            user.Privileged_Leave=((int)dr["Privileged_Leave"]);
            user.Compansatory_Leave=((int)dr["Compansatory_Leave"]);
            user.Maternity_Leave=((int)dr["Maternity_Leave"]);
            user.Paternity_Leave=((int)dr["Paternity_Leave"]);
            user.LOP_Leave=((int)dr["LOP_Leave"]);
            user.Carry_Forward=((int)dr["Carry_Leave"]);
            user.Encashed_Days=((int)dr["Encashed_Leave"]);
            user.Marriage_Leave=((int)dr["Marriage_Leave"]);
            user. MTP_Leave=((int)dr["MTP_Leave"]);
            user.DateTime=Convert.ToString(dr["DateTime"]);
            
            names.Add(user);
            
              
              
              }
            connection.Close();
                 
                return "ok";
               
                
             }
            else
            {
                return "NotoK";
            }
            // }
            // return "NotOk";
        }
            
        
        public static string RemoveDetails(CancelRequest RLD)
        {   
             
             

            connection.Open();
            SqlCommand command4=new SqlCommand("select count(*) from Table_3 where Userid='"+RLD.ID+"'AND  UserName='"+RLD.Name+"' AND  Start_Date ='"+RLD.SDate+"' AND End_Date='"+RLD.EDate+"' ;",connection );
            int count = Convert.ToInt32(command4.ExecuteScalar());
            // Console.WriteLine(count);
            connection.Close();
            if(count>0)
            {
                try{

              connection.Open();
              SqlCommand command1=new SqlCommand("delete from Table_3 where Userid='"+RLD.ID+"' and UserName='"+RLD.Name+"' and Start_Date ='"+RLD.SDate+"' and End_Date='"+RLD.EDate+"' ;",connection );
              command1.ExecuteNonQuery();
              return "ok";
                }
                catch(SqlException ex)
                {
                    Console.WriteLine("SqlException"+ex);
                }
                catch(Exception e)
                {
                    Console.WriteLine(e);
                }
                finally{
              connection.Close();
              }
              

           
            }
             return "Notok";
        }
      
            
                
    }

}    

    


