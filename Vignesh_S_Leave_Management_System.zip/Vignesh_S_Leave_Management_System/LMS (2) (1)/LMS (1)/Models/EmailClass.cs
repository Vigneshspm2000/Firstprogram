using System;
namespace LMS.Models
{
    public class EmailClass
    {
        public string ? to {get; set;}
        public string ? subject {get ; set;}
        public string ? Body {get; set;}
    }

}