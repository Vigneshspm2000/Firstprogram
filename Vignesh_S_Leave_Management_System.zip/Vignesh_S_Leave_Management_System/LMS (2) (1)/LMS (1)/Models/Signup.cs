using System;
namespace LMS.Models{
    public class Signup{
        
        public string? UserName{get; set;}
       
        public string? PassWord {get; set;}
        public string ? UserID {get;set;}

        
       
    
       
    }
    
}